-- ============================================================
--  WEB4ALL – Base de données
--  Import : phpMyAdmin > Importer > database.sql
--  Mot de passe de tous les comptes de test : password
-- ============================================================

DROP DATABASE IF EXISTS web4all;
CREATE DATABASE web4all CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE web4all;

-- ============================================================
--  TABLES
-- ============================================================

CREATE TABLE promotions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    annee       YEAR         NOT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE entreprises (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    nom             VARCHAR(200) NOT NULL,
    secteur         VARCHAR(150) DEFAULT NULL,
    adresse         VARCHAR(255) DEFAULT NULL,
    ville           VARCHAR(100) DEFAULT NULL,
    code_postal     VARCHAR(10)  DEFAULT NULL,
    pays            VARCHAR(80)  DEFAULT 'France',
    email_contact   VARCHAR(180) DEFAULT NULL,
    telephone       VARCHAR(30)  DEFAULT NULL,
    site_web        VARCHAR(255) DEFAULT NULL,
    description     TEXT         DEFAULT NULL,
    nb_stagiaires   INT          DEFAULT 0,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE utilisateurs (
    id                     INT AUTO_INCREMENT PRIMARY KEY,
    prenom                 VARCHAR(80)  NOT NULL,
    nom                    VARCHAR(80)  NOT NULL,
    email                  VARCHAR(180) NOT NULL UNIQUE,
    password               VARCHAR(255) NOT NULL,
    role                   ENUM('etudiant','pilote','admin') NOT NULL DEFAULT 'etudiant',
    promotion_id           INT          DEFAULT NULL,
    entreprise_id          INT          DEFAULT NULL,
    nom_entreprise_demande VARCHAR(200) DEFAULT NULL,
    statut                 ENUM('actif','en_attente','suspendu') NOT NULL DEFAULT 'actif',
    cv_path                VARCHAR(255) DEFAULT NULL,
    reset_token            VARCHAR(64)  DEFAULT NULL,
    reset_token_expires    DATETIME     DEFAULT NULL,
    created_at             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (promotion_id)  REFERENCES promotions(id)   ON DELETE SET NULL,
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id)  ON DELETE SET NULL
);

CREATE TABLE competences (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nom       VARCHAR(100) NOT NULL UNIQUE,
    categorie VARCHAR(80)  DEFAULT NULL
);

CREATE TABLE offres (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    titre             VARCHAR(200) NOT NULL,
    entreprise_id     INT          NOT NULL,
    lieu              VARCHAR(100) NOT NULL,
    type              ENUM('stage','alternance') NOT NULL,
    description       TEXT         NOT NULL,
    duree             VARCHAR(80)  DEFAULT NULL,
    remuneration      VARCHAR(80)  DEFAULT NULL,
    lat               DECIMAL(9,6) DEFAULT NULL,
    lng               DECIMAL(9,6) DEFAULT NULL,
    actif             TINYINT(1)   NOT NULL DEFAULT 1,
    statut_validation ENUM('validee','en_attente','refusee') NOT NULL DEFAULT 'validee',
    created_by        INT          DEFAULT NULL,
    created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id)   ON DELETE CASCADE,
    FOREIGN KEY (created_by)    REFERENCES utilisateurs(id)  ON DELETE SET NULL
);

CREATE TABLE offre_competences (
    offre_id      INT NOT NULL,
    competence_id INT NOT NULL,
    PRIMARY KEY (offre_id, competence_id),
    FOREIGN KEY (offre_id)      REFERENCES offres(id)      ON DELETE CASCADE,
    FOREIGN KEY (competence_id) REFERENCES competences(id) ON DELETE CASCADE
);

CREATE TABLE etudiant_competences (
    utilisateur_id INT NOT NULL,
    competence_id  INT NOT NULL,
    PRIMARY KEY (utilisateur_id, competence_id),
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (competence_id)  REFERENCES competences(id)  ON DELETE CASCADE
);

CREATE TABLE candidatures (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT  NOT NULL,
    offre_id       INT  NOT NULL,
    message        TEXT NOT NULL,
    statut         ENUM('envoyee','vue','acceptee','refusee') NOT NULL DEFAULT 'envoyee',
    cv_path        VARCHAR(255) DEFAULT NULL,
    lm_path        VARCHAR(255) DEFAULT NULL,
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (offre_id)       REFERENCES offres(id)       ON DELETE CASCADE,
    UNIQUE KEY unique_candidature (utilisateur_id, offre_id)
);

-- ============================================================
--  PROMOTIONS
-- ============================================================

INSERT INTO promotions (nom, annee, description) VALUES
('BTS SIO SLAM 2025', 2025, 'Solutions Logicielles et Applications Métiers'),
('BTS SIO SISR 2025', 2025, 'Solutions Infrastructure, Systèmes et Réseaux'),
('LP DevWeb 2025',    2025, 'Licence Professionnelle Développement Web');

-- ============================================================
--  COMPÉTENCES
-- ============================================================

INSERT INTO competences (nom, categorie) VALUES
('PHP',              'Développement'),
('JavaScript',       'Développement'),
('React',            'Développement'),
('Node.js',          'Développement'),
('Python',           'Développement'),
('TypeScript',       'Développement'),
('SQL',              'Base de données'),
('MySQL',            'Base de données'),
('PostgreSQL',       'Base de données'),
('MongoDB',          'Base de données'),
('Linux',            'Système'),
('Windows Server',   'Système'),
('Docker',           'DevOps'),
('Kubernetes',       'DevOps'),
('Git',              'DevOps'),
('CI/CD',            'DevOps'),
('Ansible',          'DevOps'),
('Réseau',           'Réseau'),
('VLAN',             'Réseau'),
('Firewall',         'Réseau'),
('VPN',              'Réseau'),
('Figma',            'Design'),
('UX/UI',            'Design'),
('Photoshop',        'Design'),
('Power BI',         'Data'),
('Python Data',      'Data'),
('Machine Learning', 'Data');

-- ============================================================
--  ENTREPRISES  (id 1 → 12)
-- ============================================================

INSERT INTO entreprises (nom, secteur, ville, code_postal, email_contact, telephone, site_web, description, nb_stagiaires) VALUES
('TechNormandie',    'Développement web',    'Rouen',    '76000', 'contact@technormandie.fr',    '02 35 00 11 22', 'https://technormandie.fr',   'Agence web spécialisée React/Node.js. Équipe de 25 développeurs passionnés.',            3),
('InfoServices SAS', 'Infrastructure IT',    'Le Havre', '76600', 'rh@infoservices.fr',          '02 35 00 33 44', 'https://infoservices.fr',    'Administration systèmes Linux/VMware. Certifiée ISO 27001.',                             5),
('CyberNord',        'Cybersécurité',        'Caen',     '14000', 'stages@cybernord.fr',         '02 31 00 55 66', 'https://cybernord.fr',       'Audit, pentest et conseil en sécurité pour les PME du Grand Ouest.',                     2),
('CloudFactory',     'DevOps / Cloud',       'Rouen',    '76000', 'recrutement@cloudfactory.io', '02 35 00 77 88', 'https://cloudfactory.io',    'Plateforme cloud AWS/Azure et automatisation CI/CD pour clients grands comptes.',         4),
('PixelStudio',      'Design UX/UI',         'Paris',    '75009', 'jobs@pixelstudio.fr',         '01 42 00 11 22', 'https://pixelstudio.fr',     'Studio de design produit reconnu, partenaire de startups du CAC 40.',                    6),
('DataWave',         'Data / BI',            'Paris',    '75002', 'hr@datawave.fr',              '01 42 00 33 44', 'https://datawave.fr',        'Analyse de données et dashboards BI pour le secteur bancaire et retail.',                 3),
('HelpDesk76',       'Support IT',           'Le Havre', '76600', 'contact@helpdesk76.fr',       '02 35 00 99 00', 'https://helpdesk76.fr',      'Support utilisateurs N1/N2 et gestion de parc informatique multi-sites.',                 8),
('AppFactory',       'Développement mobile', 'Rouen',    '76000', 'stage@appfactory.fr',         '02 35 00 12 34', 'https://appfactory.fr',      'Applications mobiles React Native pour e-commerce et santé.',                            2),
('NordTech',         'Développement web',    'Lille',    '59000', 'contact@nordtech.fr',         '03 20 00 11 22', 'https://nordtech.fr',        'ESN lilloise spécialisée en développement web et mobile, 80 collaborateurs.',             4),
('InfraLille',       'Infrastructure IT',    'Lille',    '59000', 'rh@infralille.fr',            '03 20 00 33 44', 'https://infralille.fr',      'Hébergement et infogérance pour TPE/PME du Nord-Pas-de-Calais.',                         3),
('DataNord',         'Data / BI',            'Lille',    '59000', 'jobs@datanord.fr',            '03 20 00 55 66', 'https://datanord.fr',        'Cabinet de conseil en data science et intelligence artificielle.',                       2),
('SecureLille',      'Cybersécurité',        'Lille',    '59100', 'stages@securelille.fr',       '03 20 00 77 88', 'https://securelille.fr',     'SOC et réponse à incident pour le secteur industriel du Nord.',                           1);

-- ============================================================
--  UTILISATEURS
--  Tous les comptes ont le mot de passe : password
-- ============================================================

SET @h = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

INSERT INTO utilisateurs (prenom, nom, email, password, role, promotion_id, entreprise_id, statut, nom_entreprise_demande) VALUES
-- ── Admin ────────────────────────────────────────────────────
('Admin',    'Web4All',  'admin@web4all.fr',          @h, 'admin',    NULL, NULL, 'actif',      NULL),

-- ── Pilotes actifs (1 pilote par entreprise) ─────────────────
('Thomas',   'Leroy',    'pilote.rouen@web4all.fr',   @h, 'pilote',   NULL, 1,   'actif',      NULL),
('Julie',    'Moreau',   'pilote.havre@web4all.fr',   @h, 'pilote',   NULL, 2,   'actif',      NULL),
('Marc',     'Petit',    'pilote.caen@web4all.fr',    @h, 'pilote',   NULL, 3,   'actif',      NULL),
('Sophie',   'Bernard',  'pilote.paris@web4all.fr',   @h, 'pilote',   NULL, 5,   'actif',      NULL),
('Kevin',    'Durand',   'pilote.lille@web4all.fr',   @h, 'pilote',   NULL, 9,   'actif',      NULL),

-- ── Pilote en attente de validation ──────────────────────────
('Laura',    'Simon',    'pilote.attente@web4all.fr', @h, 'pilote',   NULL, NULL,'en_attente', 'StartupNord – Lille'),

-- ── Étudiants – Promo 1 : BTS SIO SLAM ───────────────────────
('Lucas',    'Martin',   'etudiant1@web4all.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Emma',     'Dubois',   'etudiant2@web4all.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Noah',     'Fontaine', 'etudiant3@web4all.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Chloé',    'Laurent',  'chloe.laurent@bts.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Hugo',     'Moreau',   'hugo.moreau@bts.fr',        @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Jade',     'Petit',    'jade.petit@bts.fr',         @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Théo',     'Simon',    'theo.simon@bts.fr',         @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Léa',      'Bernard',  'lea.bernard@bts.fr',        @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Antoine',  'Dupont',   'antoine.dupont@bts.fr',     @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Manon',    'Richard',  'manon.richard@bts.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Romain',   'Thomas',   'romain.thomas@bts.fr',      @h, 'etudiant', 1,   NULL, 'actif',     NULL),
('Camille',  'Garcia',   'camille.garcia@bts.fr',     @h, 'etudiant', 1,   NULL, 'actif',     NULL),

-- ── Étudiants – Promo 2 : BTS SIO SISR ───────────────────────
('Louis',    'Robert',   'louis.robert@sisr.fr',      @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Sarah',    'Martinez', 'sarah.martinez@sisr.fr',    @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Enzo',     'Lopez',    'enzo.lopez@sisr.fr',        @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Inès',     'Gonzalez', 'ines.gonzalez@sisr.fr',     @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Axel',     'Wilson',   'axel.wilson@sisr.fr',       @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Zoé',      'Anderson', 'zoe.anderson@sisr.fr',      @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Nathan',   'Taylor',   'nathan.taylor@sisr.fr',     @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Pauline',  'Moore',    'pauline.moore@sisr.fr',     @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Alexis',   'Jackson',  'alexis.jackson@sisr.fr',    @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Clara',    'White',    'clara.white@sisr.fr',       @h, 'etudiant', 2,   NULL, 'actif',     NULL),
('Maxime',   'Harris',   'maxime.harris@sisr.fr',     @h, 'etudiant', 2,   NULL, 'actif',     NULL),

-- ── Étudiants – Promo 3 : LP DevWeb ──────────────────────────
('Eva',      'Martin',   'eva.martin@lp.fr',          @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Pierre',   'Davies',   'pierre.davies@lp.fr',       @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Alice',    'Evans',    'alice.evans@lp.fr',         @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Victor',   'Turner',   'victor.turner@lp.fr',       @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Lucie',    'Collins',  'lucie.collins@lp.fr',       @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Florian',  'Stewart',  'florian.stewart@lp.fr',     @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Anaïs',    'Morris',   'anais.morris@lp.fr',        @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Dylan',    'Rogers',   'dylan.rogers@lp.fr',        @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Océane',   'Reed',     'oceane.reed@lp.fr',         @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Baptiste', 'Cook',     'baptiste.cook@lp.fr',       @h, 'etudiant', 3,   NULL, 'actif',     NULL),
('Ambre',    'Bell',     'ambre.bell@lp.fr',          @h, 'etudiant', 3,   NULL, 'actif',     NULL);

-- ============================================================
--  OFFRES  (54 validées + 1 en attente)
--  created_by : 2=Thomas, 3=Julie, 4=Marc, 5=Sophie, 6=Kevin
-- ============================================================

INSERT INTO offres (titre, entreprise_id, lieu, type, description, duree, remuneration, lat, lng, statut_validation, created_by) VALUES

-- ── TechNormandie (1) · Rouen ─────────────────────────────────
('Stage Développeur Web Full-Stack',            1, 'Rouen',    'stage',      'Rejoignez notre équipe Agile pour développer des applications web modernes en React et Node.js. Participation aux daily stand-ups, code reviews et démos clients.',                                                                     '6 mois', '560 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage Développeur Front-End React',           1, 'Rouen',    'stage',      'Développez des composants React pour nos clients e-commerce avec TypeScript, Redux et des outils de test (Jest, Cypress). Équipe de 8 développeurs en méthode Scrum.',                                                                   '3 mois', '570 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage QA / Testeur Logiciel',                 1, 'Rouen',    'stage',      'Rédigez et exécutez des plans de tests (fonctionnels, non-régressifs, de performance). Automatisez les tests avec Cypress et Playwright. Collaboration quotidienne avec les développeurs.',                                               '6 mois', '560 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage Intégrateur Web HTML/CSS/JS',           1, 'Rouen',    'stage',      'Intégrez des maquettes Figma en pages web responsive pour des projets e-commerce, en binôme avec un développeur senior. Maîtrise du CSS et de JavaScript attendue.',                                                                     '3 mois', '560 €/mois',  49.4431,  1.0993, 'validee',    2),
('Alternance Développeur Full-Stack',           1, 'Rouen',    'alternance', 'Développez des applications web complètes en React/Node.js de la conception au déploiement. Formation aux bonnes pratiques CI/CD incluse.',                                                                                               '2 ans',  '950 €/mois',  49.4431,  1.0993, 'validee',    2),
('Alternance Développeur Back-End PHP',         1, 'Rouen',    'alternance', 'Développez et maintenez nos APIs REST en PHP/Symfony. Revues de code et mises en production hebdomadaires sur AWS, participation aux choix d''architecture.',                                                                             '2 ans',  '920 €/mois',  49.4431,  1.0993, 'validee',    2),

-- ── InfoServices SAS (2) · Le Havre ──────────────────────────
('Alternance Administrateur Systèmes Linux',    2, 'Le Havre', 'alternance', 'Gérez notre infrastructure Linux (70 serveurs) : supervision Zabbix, automatisation Ansible, mise à jour des procédures ITIL. Formation certifiante Red Hat prévue.',                                                                    '2 ans',  '900 €/mois',  49.4944,  0.1079, 'validee',    3),
('Stage Technicien Systèmes & Réseaux',         2, 'Le Havre', 'stage',      'Administrez notre parc de serveurs Linux et Windows Server : Active Directory, supervision Nagios, déploiement de patchs, rédaction de procédures. Environnement multi-sites.',                                                         '4 mois', '560 €/mois',  49.4944,  0.1079, 'validee',    3),
('Stage Administrateur Virtualisation',         2, 'Le Havre', 'stage',      'Gérez notre environnement VMware vSphere (200 VMs) : création de VMs, snapshots, migrations vMotion, monitoring des performances. Formation VMware VCP proposée en fin de stage.',                                                       '6 mois', '570 €/mois',  49.4944,  0.1079, 'validee',    3),
('Stage Administrateur Réseaux Cisco',          2, 'Le Havre', 'stage',      'Configurez switches Cisco, mettez en place des VLANs et rédigez la documentation réseau pour 3 sites clients. Encadré par un ingénieur CCNP.',                                                                                          '4 mois', '560 €/mois',  49.4944,  0.1079, 'validee',    3),
('Alternance Ingénieur Systèmes Linux',         2, 'Le Havre', 'alternance', 'Gérez l''infrastructure Linux de nos 120 clients PME. Automatisez les tâches récurrentes avec Ansible et Python. Participez à la migration cloud hybride (Azure + on-premise).',                                                        '2 ans',  '980 €/mois',  49.4944,  0.1079, 'validee',    3),

-- ── CyberNord (3) · Caen ─────────────────────────────────────
('Stage Réseau & Sécurité',                     3, 'Caen',     'stage',      'Participez à des missions d''audit réseau et de configuration de firewalls pfSense. Rédigez des rapports techniques et proposez des plans de remédiation à nos clients PME.',                                                            '4 mois', '560 €/mois',  49.1829, -0.3707, 'validee',    4),
('Stage Pentester Junior',                      3, 'Caen',     'stage',      'Réalisez des tests d''intrusion sur des applications web et des infrastructures réseau. Rédigez des rapports détaillés et présentez vos résultats. Maîtrise de Kali Linux souhaitée.',                                                    '6 mois', '600 €/mois',  49.1829, -0.3707, 'validee',    4),
('Stage Analyste SOC – Splunk',                 3, 'Caen',     'stage',      'Analysez les alertes remontées par notre SIEM Splunk. Qualifiez les incidents, rédigez les rapports et proposez des mesures de remédiation pour nos clients PME.',                                                                        '6 mois', '580 €/mois',  49.1829, -0.3707, 'validee',    4),
('Stage Analyste Malware',                      3, 'Caen',     'stage',      'Analysez des échantillons de malware dans un environnement sandboxé. Rédigez des rapports d''analyse et proposez des règles de détection YARA/Sigma. Encadré par un expert OSCP.',                                                       '4 mois', '580 €/mois',  49.1829, -0.3707, 'validee',    4),
('Alternance Consultant Cybersécurité',         3, 'Caen',     'alternance', 'Accompagnez nos clients PME : audits ISO 27001, analyse de risques, rédaction de PSSI. Certification CISSP ou CISM financée par l''entreprise.',                                                                                         '2 ans',  '900 €/mois',  49.1829, -0.3707, 'validee',    4),

-- ── CloudFactory (4) · Rouen ──────────────────────────────────
('Alternance DevOps Cloud',                     4, 'Rouen',    'alternance', 'Intégrez notre squad DevOps : pipelines GitLab CI/CD, orchestration Docker/Kubernetes sur AWS, scripts Terraform. Astreinte et post-mortems d''incidents inclus.',                                                                       '2 ans',  '1000 €/mois', 49.4431,  1.0993, 'validee',    2),
('Stage Ingénieur DevOps',                      4, 'Rouen',    'stage',      'Mettez en place des pipelines CI/CD sur GitLab, gérez des conteneurs Docker et des clusters Kubernetes. Rédigez des modules Terraform pour le provisionnement AWS.',                                                                      '6 mois', '600 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage Développeur Infrastructure as Code',    4, 'Rouen',    'stage',      'Développez et maintenez nos modules Terraform et Ansible. Documentez les architectures cloud et participez aux revues de code infrastructure. Environnement AWS multi-comptes.',                                                          '4 mois', '570 €/mois',  49.4431,  1.0993, 'validee',    2),
('Alternance SRE – Site Reliability Engineer',  4, 'Rouen',    'alternance', 'Assurez la fiabilité de nos plateformes cloud (SLA 99,9%). SLO/SLI, runbooks automatisés, astreintes et post-mortems. Stack : Prometheus, Grafana, PagerDuty.',                                                                         '2 ans',  '1050 €/mois', 49.4431,  1.0993, 'validee',    2),

-- ── PixelStudio (5) · Paris ───────────────────────────────────
('Stage UX/UI Designer',                        5, 'Paris',    'stage',      'Créez des interfaces mémorables pour nos clients startups : wireframes, prototypes Figma, tests utilisateurs. Participation aux ateliers de co-design et aux présentations clients.',                                                     '6 mois', '600 €/mois',  48.8566,  2.3522, 'validee',    5),
('Stage Designer UI – Applications Mobiles',    5, 'Paris',    'stage',      'Concevez les interfaces de nos applications mobiles iOS/Android. Créez des design systems cohérents, réalisez des tests A/B et itérez avec les développeurs React Native. Portfolio obligatoire.',                                        '3 mois', '610 €/mois',  48.8566,  2.3522, 'validee',    5),
('Stage Designer Graphique & Brand',            5, 'Paris',    'stage',      'Créez des supports de communication (identité visuelle, charte graphique, print et digital). Maîtrise d''Illustrator et Photoshop requise. Figma est un plus.',                                                                          '6 mois', '590 €/mois',  48.8566,  2.3522, 'validee',    5),
('Stage Product Designer – SaaS',               5, 'Paris',    'stage',      'Concevez l''UX de nouvelles fonctionnalités pour nos clients SaaS. Entretiens utilisateurs, prototypes Figma et itérations avec les équipes dev. Portfolio requis.',                                                                      '6 mois', '620 €/mois',  48.8566,  2.3522, 'validee',    5),
('Alternance UX Researcher',                    5, 'Paris',    'alternance', 'Menez des recherches utilisateurs (entretiens, tests d''usabilité, analytics). Transformez les insights en recommandations design sur des produits SaaS avec 50 000+ utilisateurs actifs.',                                               '2 ans',  '920 €/mois',  48.8566,  2.3522, 'validee',    5),
('Alternance Motion Designer',                  5, 'Paris',    'alternance', 'Créez des animations pour les interfaces produit de nos clients. Stack : After Effects, Lottie, Figma. Collaboration directe avec les équipes produit et marketing.',                                                                     '2 ans',  '900 €/mois',  48.8566,  2.3522, 'validee',    5),

-- ── DataWave (6) · Paris ──────────────────────────────────────
('Alternance Data Analyst',                     6, 'Paris',    'alternance', 'Analysez les données de nos clients retail et bancaires. Construisez des dashboards Power BI, automatisez des ETL Python et présentez vos résultats au COMEX. Accès aux datasets réels dès J+1.',                                        '2 ans',  '950 €/mois',  48.8566,  2.3522, 'validee',    5),
('Stage Data Engineer',                         6, 'Paris',    'stage',      'Construisez et maintenez nos pipelines ETL avec Python et Apache Airflow. Alimentez notre data warehouse Snowflake et optimisez les requêtes SQL pour nos clients retail.',                                                                '6 mois', '620 €/mois',  48.8566,  2.3522, 'validee',    5),
('Stage Business Analyst – BI & Reporting',     6, 'Paris',    'stage',      'Analysez les données clients et construisez des tableaux de bord Power BI et Tableau. Rédigez les spécifications fonctionnelles et animez les comités de pilotage.',                                                                      '4 mois', '600 €/mois',  48.8566,  2.3522, 'validee',    5),
('Alternance Machine Learning Engineer',        6, 'Paris',    'alternance', 'Développez et déployez des modèles ML en production. Stack : Python, scikit-learn, TensorFlow, MLflow. Cas d''usage réels : recommandation, prédiction de churn, détection de fraude.',                                                  '2 ans',  '1000 €/mois', 48.8566,  2.3522, 'validee',    5),

-- ── HelpDesk76 (7) · Le Havre ────────────────────────────────
('Stage Technicien Support N2',                 7, 'Le Havre', 'stage',      'Traitez les tickets N2 (réseau, OS, applicatif) sur notre plateforme Jira. Astreinte hebdomadaire et rédaction de procédures pour notre base de connaissance.',                                                                          '3 mois', '560 €/mois',  49.4944,  0.1079, 'validee',    3),
('Stage Technicien Support N1/N2',              7, 'Le Havre', 'stage',      'Traitez les tickets utilisateurs via ServiceNow. Diagnostiquez et résolvez les incidents matériels, logiciels et réseau. Rédigez les procédures pour la base de connaissance.',                                                          '3 mois', '560 €/mois',  49.4944,  0.1079, 'validee',    3),
('Alternance Responsable Parc Informatique',    7, 'Le Havre', 'alternance', 'Gérez un parc de 500 postes (déploiement SCCM, imaging, inventaire). Migration Windows 11 et M365. Encadrement de 2 techniciens junior en fin d''alternance.',                                                                           '2 ans',  '870 €/mois',  49.4944,  0.1079, 'validee',    3),

-- ── AppFactory (8) · Rouen ────────────────────────────────────
('Alternance Développeur Mobile React Native',  8, 'Rouen',    'alternance', 'Développez des apps iOS/Android pour l''e-commerce et la santé. Stack : React Native, TypeScript, GraphQL. Publication sur les stores, suivi des KPIs et A/B testing inclus.',                                                          '2 ans',  '900 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage Développeur iOS Swift',                 8, 'Rouen',    'stage',      'Développez de nouvelles fonctionnalités sur notre application de santé (100K téléchargements). Stack : Swift, SwiftUI, CoreData. Sprints de 2 semaines.',                                                                                 '6 mois', '580 €/mois',  49.4431,  1.0993, 'validee',    2),
('Stage Développeur React Native',              8, 'Rouen',    'stage',      'Développement cross-platform d''une nouvelle app de livraison. Stack : React Native, TypeScript, Redux Toolkit, Firebase. Publication sur App Store et Play Store incluse.',                                                              '4 mois', '570 €/mois',  49.4431,  1.0993, 'validee',    2),
('Alternance Développeur Android Kotlin',       8, 'Rouen',    'alternance', 'Maintenez et faites évoluer notre application e-commerce Android (4,5★ Play Store). Stack : Kotlin, Jetpack Compose, Retrofit, Room. Tests Espresso inclus.',                                                                             '2 ans',  '930 €/mois',  49.4431,  1.0993, 'validee',    2),

-- ── NordTech (9) · Lille ──────────────────────────────────────
('Stage Développeur Web – Symfony/Vue.js',      9, 'Lille',    'stage',      'Participez au développement de notre CRM interne en Symfony 6 et Vue.js 3. Équipe de 8 développeurs, méthode Scrum avec des sprints de 2 semaines.',                                                                                     '6 mois', '580 €/mois',  50.6292,  3.0573, 'validee',    6),
('Stage Développeur Back-End Node.js',          9, 'Lille',    'stage',      'Développez les APIs REST de notre plateforme SaaS B2B en Node.js/Express. Tests Jest, documentation Swagger, code reviews hebdomadaires.',                                                                                                '4 mois', '575 €/mois',  50.6292,  3.0573, 'validee',    6),
('Stage Développeur Vue.js',                    9, 'Lille',    'stage',      'Créez des interfaces dynamiques en Vue.js 3 pour notre outil de gestion de projet. Composition API, Pinia, Vue Router. Collaboration quotidienne avec l''équipe back-end.',                                                              '3 mois', '565 €/mois',  50.6292,  3.0573, 'validee',    6),
('Stage Développeur Full-Stack Node.js',        9, 'Lille',    'stage',      'Développez de nouvelles fonctionnalités sur notre plateforme B2B en Node.js/React. Sprints Agile, tests unitaires et documentation technique.',                                                                                           '6 mois', '590 €/mois',  50.6292,  3.0573, 'validee',    6),
('Alternance Développeur PHP Symfony',          9, 'Lille',    'alternance', 'Contribuez au développement de notre ERP interne en Symfony 6. Migrations BDD, services métier, tests unitaires et d''intégration. Environnement Docker/PostgreSQL.',                                                                    '2 ans',  '940 €/mois',  50.6292,  3.0573, 'validee',    6),
('Alternance Ingénieur Cloud AWS',              9, 'Lille',    'alternance', 'Gérez notre infrastructure AWS avec Terraform. Monitoring CloudWatch, optimisation des coûts et politique de sécurité cloud.',                                                                                                            '2 ans',  '1050 €/mois', 50.6292,  3.0573, 'validee',    6),

-- ── InfraLille (10) · Lille ───────────────────────────────────
('Alternance Technicien Infogérance',          10, 'Lille',    'alternance', 'Gérez le parc de 200 postes clients. Missions : déploiement SCCM, gestion Active Directory, supervision Centreon. Formation ITIL Foundation offerte.',                                                                                   '2 ans',  '880 €/mois',  50.6292,  3.0573, 'validee',    6),
('Stage Administrateur Cloud Azure',           10, 'Lille',    'stage',      'Gérez et optimisez notre infrastructure Azure (VMs, AKS, Azure AD). Politiques de sécurité et scripts PowerShell. Préparation AZ-900 offerte.',                                                                                          '6 mois', '580 €/mois',  50.6292,  3.0573, 'validee',    6),
('Alternance Ingénieur Réseau & Sécurité',     10, 'Lille',    'alternance', 'Gérez l''infrastructure réseau de nos 80 clients PME (Cisco, Fortinet). Solutions SD-WAN, VPNs IPSEC et audits de sécurité trimestriels.',                                                                                               '2 ans',  '890 €/mois',  50.6292,  3.0573, 'validee',    6),

-- ── DataNord (11) · Lille ─────────────────────────────────────
('Stage Data Scientist – IA / ML',             11, 'Lille',    'stage',      'Travaillez sur des modèles de machine learning pour la prédiction de churn client. Stack : Python, scikit-learn, TensorFlow, MLflow, Jupyter. Encadré par un PhD en IA.',                                                                '6 mois', '620 €/mois',  50.6292,  3.0573, 'validee',    6),
('Stage Data Scientist – NLP',                 11, 'Lille',    'stage',      'Développez des modèles de traitement du langage naturel pour l''analyse de sentiment client. Stack : Python, HuggingFace Transformers, spaCy, FastAPI. Données réelles dès J+1.',                                                        '6 mois', '615 €/mois',  50.6292,  3.0573, 'validee',    6),
('Alternance Data Analyst – E-commerce',       11, 'Lille',    'alternance', 'Analysez les données de vente de nos clients e-commerce (CA 10M€+). Modèles prédictifs, reportings automatisés et présentations COMEX chaque semaine.',                                                                                  '2 ans',  '960 €/mois',  50.6292,  3.0573, 'validee',    6),

-- ── SecureLille (12) · Lille ──────────────────────────────────
('Stage Analyste Cybersécurité / SOC',         12, 'Lille',    'stage',      'Intégrez notre SOC 24/7 et analysez les alertes SIEM Splunk. Simulations d''attaques (purple team), rédaction de playbooks, formation CompTIA Security+.',                                                                               '4 mois', '570 €/mois',  50.6270,  3.0620, 'validee',    6),
('Stage Ingénieur Sécurité Cloud',             12, 'Lille',    'stage',      'Auditez la sécurité des environnements cloud de nos clients industriels (AWS, Azure, GCP). Rédigez des plans de remédiation et accompagnez les équipes dans leur mise en œuvre.',                                                         '4 mois', '590 €/mois',  50.6270,  3.0620, 'validee',    6),
('Alternance Architecte Sécurité',             12, 'Lille',    'alternance', 'Définissez et pilotez la stratégie de sécurité de nos clients grand compte. Zero Trust, SASE, SOAR. Certification OSCP ou CEH financée par l''entreprise.',                                                                              '2 ans',  '1020 €/mois', 50.6270,  3.0620, 'validee',    6),

-- ── Offre en attente de validation ────────────────────────────
('Alternance Développeur PHP/Laravel',          9, 'Lille',    'alternance', 'Développez de nouvelles fonctionnalités sur notre plateforme SaaS en PHP/Laravel. TDD, revue de code et déploiement continu inclus.',                                                                                                    '2 ans',  '920 €/mois',  50.6292,  3.0573, 'en_attente', 6);

-- ============================================================
--  COMPÉTENCES PAR OFFRE
-- ============================================================

INSERT INTO offre_competences (offre_id, competence_id) VALUES
-- TechNormandie
(1,  1),(1,  2),(1,  3),(1,  4),(1,  8),   -- Stage Dev Web Full-Stack
(2,  2),(2,  3),(2,  6),(2,  8),            -- Stage Front-End React
(3,  2),(3,  6),(3, 15),                    -- Stage QA
(4,  2),(4,  3),(4, 22),                    -- Stage Intégrateur
(5,  1),(5,  2),(5,  3),(5,  4),(5, 15),    -- Alt Full-Stack
(6,  1),(6,  8),(6, 15),                    -- Alt Back-End PHP
-- InfoServices SAS
(7,  11),(7, 12),(7, 15),(7, 17),           -- Alt Admin Linux
(8,  11),(8, 12),(8, 18),                   -- Stage Technicien S&R
(9,  11),(9, 15),                           -- Stage Virtualisation
(10, 18),(10,19),(10,15),                   -- Stage Admin Réseaux
(11, 11),(11,17),(11,15),(11, 5),           -- Alt Ingénieur Linux
-- CyberNord
(12, 18),(12,20),(12,21),                   -- Stage Réseau & Sécu
(13, 18),(13,20),(13,11),                   -- Stage Pentester
(14, 18),(14,20),(14,11),                   -- Stage Analyste SOC
(15, 18),(15,20),(15,11),                   -- Stage Analyste Malware
(16, 18),(16,20),(16,21),                   -- Alt Consultant Cybersec
-- CloudFactory
(17, 13),(17,14),(17,15),(17,16),           -- Alt DevOps Cloud
(18, 13),(18,14),(18,15),(18,16),           -- Stage Ingénieur DevOps
(19, 13),(19,17),(19,15),                   -- Stage IaC
(20, 13),(20,14),(20,16),                   -- Alt SRE
-- PixelStudio
(21, 22),(21,23),                           -- Stage UX/UI Designer
(22, 22),(22,23),                           -- Stage Designer UI Mobile
(23, 22),(23,24),                           -- Stage Designer Graphique
(24, 22),(24,23),                           -- Stage Product Designer
(25, 22),(25,23),                           -- Alt UX Researcher
(26, 22),(26,24),                           -- Alt Motion Designer
-- DataWave
(27,  5),(27,25),(27, 8),                   -- Alt Data Analyst
(28,  5),(28,25),(28, 7),                   -- Stage Data Engineer
(29, 25),(29, 7),(29, 8),                   -- Stage Business Analyst
(30,  5),(30,26),(30,27),                   -- Alt ML Engineer
-- HelpDesk76
(31, 11),(31,12),(31, 8),                   -- Stage Support N2
(32, 11),(32,12),(32, 8),                   -- Stage Support N1/N2
(33, 11),(33,12),(33,15),                   -- Alt Parc Informatique
-- AppFactory
(34,  2),(34, 3),(34, 6),                   -- Alt React Native
(35,  2),(35, 6),                           -- Stage iOS Swift
(36,  2),(36, 3),(36, 6),                   -- Stage React Native
(37,  2),(37, 6),                           -- Alt Android Kotlin
-- NordTech
(38,  1),(38, 2),(38, 8),                   -- Stage Symfony/Vue
(39,  4),(39, 2),(39,15),                   -- Stage Node.js
(40,  2),(40, 3),                           -- Stage Vue.js
(41,  2),(41, 4),(41, 3),                   -- Stage Full-Stack Node
(42,  1),(42, 9),(42,15),                   -- Alt PHP Symfony
(43, 13),(43,16),(43,15),                   -- Alt Cloud AWS
-- InfraLille
(44, 11),(44,12),(44,15),                   -- Alt Infogérance
(45, 11),(45,12),(45,13),                   -- Stage Cloud Azure
(46, 18),(46,19),(46,20),(46,21),           -- Alt Réseau & Sécurité
-- DataNord
(47,  5),(47,26),(47,27),                   -- Stage Data Scientist ML
(48,  5),(48,26),(48,27),                   -- Stage Data Scientist NLP
(49, 25),(49,26),(49, 8),                   -- Alt Data Analyst E-com
-- SecureLille
(50, 18),(50,20),(50,11),                   -- Stage Analyste SOC
(51, 13),(51,20),(51,21),                   -- Stage Sécurité Cloud
(52, 18),(52,20),(52,13),(52,21),           -- Alt Architecte Sécurité
-- Offre en attente
(53,  1),(53, 8),(53,15);                   -- Alt PHP/Laravel

-- ============================================================
--  COMPÉTENCES PAR ÉTUDIANT (exemples)
--  IDs utilisateurs : Lucas=8, Emma=9, Noah=10
-- ============================================================

INSERT INTO etudiant_competences (utilisateur_id, competence_id) VALUES
(8,  1),(8,  2),(8,  8),   -- Lucas : PHP, JS, MySQL
(9,  2),(9,  3),(9,  6),   -- Emma  : JS, React, TypeScript
(10, 11),(10,18),(10,15);  -- Noah  : Linux, Réseau, Git

-- ============================================================
--  MESSAGERIE INTERNE
-- ============================================================

CREATE TABLE conversations (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user1_id    INT NOT NULL,
    user2_id    INT NOT NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_conv (user1_id, user2_id),
    FOREIGN KEY (user1_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
    FOREIGN KEY (user2_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
);

CREATE TABLE messages (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    expediteur_id   INT NOT NULL,
    contenu         TEXT NOT NULL,
    lu              TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (expediteur_id)   REFERENCES utilisateurs(id)  ON DELETE CASCADE
);

-- ── MIGRATION : colonnes reset_token (à exécuter si la base existe déjà) ──
-- ALTER TABLE utilisateurs ADD COLUMN reset_token VARCHAR(64) DEFAULT NULL;
-- ALTER TABLE utilisateurs ADD COLUMN reset_token_expires DATETIME DEFAULT NULL;

-- ── INDEX DE PERFORMANCE ──────────────────────────────────────
-- Colonnes fréquemment utilisées dans WHERE, JOIN et ORDER BY

-- utilisateurs
CREATE INDEX idx_util_email   ON utilisateurs(email);
CREATE INDEX idx_util_statut  ON utilisateurs(statut);
CREATE INDEX idx_util_role    ON utilisateurs(role);

-- offres
CREATE INDEX idx_offres_statut     ON offres(statut_validation);
CREATE INDEX idx_offres_actif      ON offres(actif);
CREATE INDEX idx_offres_type       ON offres(type);
CREATE INDEX idx_offres_lieu       ON offres(lieu);
CREATE INDEX idx_offres_created_by ON offres(created_by);
CREATE INDEX idx_offres_created_at ON offres(created_at);

-- candidatures
CREATE INDEX idx_cand_utilisateur ON candidatures(utilisateur_id);
CREATE INDEX idx_cand_offre       ON candidatures(offre_id);
CREATE INDEX idx_cand_statut      ON candidatures(statut);

-- messages
CREATE INDEX idx_msg_conv ON messages(conversation_id);
CREATE INDEX idx_msg_lu   ON messages(lu);

-- conversations
CREATE INDEX idx_conv_user1 ON conversations(user1_id);
CREATE INDEX idx_conv_user2 ON conversations(user2_id);
